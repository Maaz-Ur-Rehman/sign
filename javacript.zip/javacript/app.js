function SignUp(){
    var a=document.getElementById('email').value;
    var b=document.getElementById('pass').value;
    localStorage.setItem('email', a)
    localStorage.setItem('password', b)

}

function SignIn(){
    var a = document.getElementById('semail').value;
    var b = document.getElementById('spass').value;
    if (a == localStorage.getItem('email') && b == localStorage.getItem('password')) {
        window.location.href = './welcome.html'
    } else {
        alert('Invalid email or Pass')
    }
} 
function LogOut(){
    window.location.href = './signin.html'

}